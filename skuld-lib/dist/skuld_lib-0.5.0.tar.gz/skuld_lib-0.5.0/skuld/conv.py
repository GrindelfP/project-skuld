##############################################################################
#  Conv-based Neural Numerical Integration
#
#  Pure convolutional architecture (no fully-connected layers) for the
#  Maitre et al. (2022) antiderivative approximation method.
#
#  Input: 1×7 image [a, b, m, n, u1, u2, u3]  (params first, matching the
#  rest of the library).
#
#  4 Conv2D layers (k=3, same padding, GELU, residual), global average
#  pooling, 1×1 conv output head → scalar N(u, θ).
#
#  Trained so that the third mixed partial ∂³N/∂u₁∂u₂∂u₃ matches f, which
#  is what makes the corner sum telescope to the integral.
#
#  Evaluation: network is transferred to CPU and converted to float64 for
#  the corner-sum evaluation, since CUDA/MPS are limited to float32.
##############################################################################

import itertools
import math
import time
from typing import Callable

import numpy as np
import torch
import torch.nn as nn


##############################################################################
#  ConvBlock: Conv2d → GELU → residual skip
##############################################################################

class ConvBlock(nn.Module):
    """Conv2d → GELU → residual skip.

    If in_ch != out_ch, a 1×1 projection shortcut is used so the skip
    connection dimensions match.
    """

    def __init__(self, in_ch: int, out_ch: int, k: int = 3):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, kernel_size=k, padding=k // 2)
        self.act = nn.GELU()
        self.use_proj = in_ch != out_ch
        if self.use_proj:
            self.proj = nn.Conv2d(in_ch, out_ch, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.act(self.conv(x))
        if self.use_proj:
            x = self.proj(x)
        return x + out


##############################################################################
#  ConvAntiderivativeNet: pure CNN, no fully-connected layers
##############################################################################

class ConvAntiderivativeNet(nn.Module):
    """
    Pure CNN antiderivative network N(u, θ) ≈ F(u) integrated over u ∈ [0,1]^3.

    Input: tensor of shape (batch, 7) — [a, b, m, n, u1, u2, u3].
    Output: tensor of shape (batch,) — scalar antiderivative value per sample.

    Architecture: 4 ConvBlock(32→64→128→256), global average pool,
    1×1 conv head → scalar. No fully-connected layers anywhere.
    """

    def __init__(
        self,
        n_params: int = 4,
        n_int_vars: int = 3,
        hidden_sizes: list = None,
    ):
        super().__init__()
        self.n_params = n_params
        self.n_int_vars = n_int_vars

        if hidden_sizes is None:
            hidden_sizes = [32, 64, 128, 256]

        # Conv blocks — channels double each layer
        blocks = []
        in_ch = 1  # the image is always 1 channel
        for h in hidden_sizes:
            blocks.append(ConvBlock(in_ch, h))
            in_ch = h
        self.blocks = nn.ModuleList(blocks)

        # Output head: 1×1 conv, last block's channels → scalar per input point
        self.head = nn.Conv2d(hidden_sizes[-1], 1, kernel_size=1)

        # Initialise head weights after construction so init is device-agnostic
        self._initialize_head(hidden_sizes[-1])

    def _initialize_head(self, fan_in: int):
        """Init head weights (called after module construction)."""
        with torch.no_grad():
            bound = math.sqrt(6.0 / fan_in)
            self.head.weight.uniform_(-bound, bound)
            if self.head.bias is not None:
                self.head.bias.fill_(0.0)

    def _process_input(self, x: torch.Tensor) -> torch.Tensor:
        """Reshape (batch, 7) → (batch, 1, 1, 7) for conv processing.

        This method is separate so that a future version can change the
        input representation (e.g., separate flows for params and
        integration variables) without touching the conv blocks.
        """
        return x.unsqueeze(1).unsqueeze(2)  # (B, 1, 1, 7)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x: tensor of shape (batch, 7) — [a, b, m, n, u1, u2, u3].

        Returns:
            tensor of shape (batch,) — scalar antiderivative value N(u,θ).
        """
        # Reshape to 1×7 image
        x = self._process_input(x)  # (B, 1, 1, 7)

        # Pass through conv blocks — each preserves 1×7 spatial size
        for block in self.blocks:
            x = block(x)  # (B, C, 1, 7)

        # Global average pooling over the 1×7 spatial grid → (B, C, 1, 1)
        x = nn.functional.adaptive_avg_pool2d(x, (1, 1))

        # 1×1 conv output head → (B, 1, 1, 1)
        x = self.head(x)

        # Flatten to (B,) — one scalar per sample
        return x.reshape(x.shape[0])


##############################################################################
#  Mixed Partial Derivative via Autograd
##############################################################################

def mixed_partial_n(net: ConvAntiderivativeNet,
                    batch: torch.Tensor) -> torch.Tensor:
    """
    d^n N / du_1 ... du_n, computed by sequential autograd, where n is the
    number of integration variables.

    This replaces a former `mixed_partial_3`, which took exactly three
    successive autograd passes over columns 0, 1, 2 regardless of the actual
    dimension. That was silently wrong for any n != 3: the network was trained
    to match a third-order partial derivative and then evaluated with an
    n-dimensional corner sum. No exception was raised, the loss decreased
    happily, and the result was confidently wrong.

    The loop below is the same computation for arbitrary n; at n = 3 it is
    identical to the previous implementation.
    """
    k = net.n_params
    s = batch[:, :k]
    u = batch[:, k:].detach().requires_grad_(True)

    dim = u.shape[1]
    declared = getattr(net, "n_int_vars", dim)
    if dim != declared:
        raise ValueError(
            f"batch has {dim} integration variables but net declares {declared}"
        )
    if dim < 1:
        raise ValueError(f"need at least 1 integration variable, got {dim}")

    g = net(torch.cat([s, u], dim=1)).squeeze(-1)

    for i in range(dim):
        # retain_graph MUST stay True even on the final pass. In
        # torch.autograd.grad an omitted retain_graph defaults to the value of
        # create_graph, so the previous three-call implementation — which
        # omitted it on the last call — was in fact retaining the graph, and
        # loss.backward() depends on that. Passing False here frees a graph the
        # backward pass still needs and raises "backward through the graph a
        # second time".
        g = torch.autograd.grad(
            g, u,
            grad_outputs=torch.ones_like(g),
            create_graph=True,
            retain_graph=True,
        )[0][:, i]

    return g


# Backwards-compatible alias: the name predates n-dimensional support.
mixed_partial_3 = mixed_partial_n


##############################################################################
#  ConvIntegrator: train + evaluate  (Maitre et al. approach)
##############################################################################

class ConvIntegrator:
    """
    CNN for numerical integration (Maitre et al. approach).

    Trains a ConvAntiderivativeNet to approximate the antiderivative, then
    evaluates the integral via an alternating-sign corner sum over the
    unit hypercube [0,1]^n_int_vars.

    Training is done in float32 on CUDA (or CPU fallback). Evaluation is
    done in float64 on CPU — the network is transferred from the training
    device and converted to float64 for the corner-sum evaluation.
    """

    def __init__(
        self,
        n_params: int = 4,
        n_int_vars: int = 3,
        hidden_sizes: list = None,
    ):
        self.n_params = n_params
        self.n_int_vars = n_int_vars
        self.net = ConvAntiderivativeNet(
            n_params=n_params,
            n_int_vars=n_int_vars,
            hidden_sizes=hidden_sizes,
        )

    @property
    def n_weights(self) -> int:
        return sum(p.numel() for p in self.net.parameters())

    def make_batch(
        self,
        integrand_fn: Callable,
        param_sets: list,
        n_per_param: int,
        device: torch.device,
        norm_cache: dict = None,
    ) -> tuple:
        """Generate a training batch: uniform in [0,1]^3 × discrete params.

        Each optimizer step consumes one full batch of
        len(param_sets) × n_per_param rows (n_per_param is the "batch size"
        knob the experiment scripts expose).
        """

        if norm_cache is None:
            norm_cache = {}

        all_xu, all_f = [], []

        for params in param_sets:
            params_key = tuple(params)
            if params_key not in norm_cache:
                norm_cache[params_key] = self._center_value(
                    integrand_fn, self.n_int_vars, *params
                )
            fc = norm_cache[params_key]

            # Uniform random points in [0,1]^3
            u_uniform = torch.rand(n_per_param, self.n_int_vars)
            f_uniform = integrand_fn(u_uniform, *params) / fc

            s = torch.tensor(params, dtype=u_uniform.dtype).expand(
                u_uniform.shape[0], -1
            )
            xu = torch.cat([s, u_uniform], dim=1)  # (n_per_param, 7)

            all_xu.append(xu)
            all_f.append(f_uniform)

        batch_xu = torch.cat(all_xu, dim=0).to(device)
        f_tilde = torch.cat(all_f, dim=0).to(device)
        return batch_xu, f_tilde, norm_cache

    @staticmethod
    def _center_value(integrand_fn, n_int_vars: int, *params) -> float:
        """Value of integrand at u=(0.5, ..., 0.5)."""
        uc = torch.full((1, n_int_vars), 0.5)
        fc = integrand_fn(uc, *params).item()
        return fc if abs(fc) > 1e-30 else 1.0

    def train(
        self,
        integrand_fn: Callable,
        param_sets: list,
        n_epochs: int = 5000,
        n_per_param: int = 512,
        lr: float = 1e-3,
        device: torch.device = None,
        verbose_every: int = 500,
        weight_decay: float = 0.0,
    ) -> tuple:
        """Train the CNN to approximate the antiderivative.

        Training is done in float32 on the specified device (CUDA preferred,
        CPU fallback). The network remains on the training device after
        training; use integrate() for float64 evaluation on CPU.
        """

        if device is None:
            device = torch.device("cpu")

        optimizer = torch.optim.Adam(
            self.net.parameters(), lr=lr, weight_decay=weight_decay
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=n_epochs, eta_min=lr / 10
        )
        self.net.to(device)
        self.net.train()

        history = []
        norm_cache = {}
        t0 = time.time()

        for epoch in range(1, n_epochs + 1):
            batch_xu, f_tilde, norm_cache = self.make_batch(
                integrand_fn, param_sets, n_per_param, device, norm_cache,
            )

            # Third mixed partial ∂³N/∂u₁∂u₂∂u₃ ≈ f, via autograd end-to-end.
            dN = mixed_partial_3(self.net, batch_xu)
            loss = ((dN - f_tilde) ** 2).mean()

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.net.parameters(), max_norm=5.0)
            optimizer.step()
            scheduler.step()

            lv = loss.item()
            history.append(lv)

            if verbose_every > 0 and (epoch % verbose_every == 0 or epoch == 1):
                lr_now = scheduler.get_last_lr()[0]
                elapsed = time.time() - t0
                print(f"  Epoch {epoch:5d}/{n_epochs}  "
                      f"loss={lv:.4e}  lr={lr_now:.2e}  "
                      f"({elapsed:.1f}s)")

        return history, norm_cache

    def integrate(self, params: tuple, norm_cache: dict = None, device: torch.device = None) -> float:
        """Evaluate the integral via corner sum over [0,1]^3 for fixed params.

        The network is transferred to CPU and converted to float64 for this
        evaluation, since CUDA/MPS are limited to float32 and the corner-sum
        is where precision matters most. This is a single forward pass per
        corner (8 corners for 3D), so the CPU transfer is cheap.

        `device` is accepted for API parity with the other integrators but
        deliberately ignored: evaluation always runs on CPU in float64.
        After evaluation the network is left on CPU in float32; train()
        moves it back to the training device.
        """

        # Always evaluate on CPU in float64 for maximum precision
        cpu_device = torch.device("cpu")

        self.net.eval()
        self.net.to(cpu_device)
        self.net.double()  # convert to float64

        if norm_cache and tuple(params) in norm_cache:
            fc = norm_cache[tuple(params)]
        else:
            fc = 1.0

        s_row = torch.tensor([params], dtype=torch.float64).to(cpu_device)
        I_tilde = 0.0

        with torch.no_grad():
            for corner in itertools.product([0.0, 1.0], repeat=self.n_int_vars):
                sign = (-1) ** (self.n_int_vars - sum(corner))
                u_t = torch.tensor([corner], dtype=torch.float64).to(cpu_device)
                inp = torch.cat([s_row, u_t], dim=1)  # (1, 7)
                I_tilde += sign * self.net(inp).item()

        # Convert back to float32 for consistency with the rest of the library
        self.net.float()

        return float(I_tilde * fc)
